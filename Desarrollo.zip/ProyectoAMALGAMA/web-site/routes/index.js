
var database = require('./../database');
var bodyParser = require('body-parser');
var express = require('express');
var session = require('express-session');
var router = express.Router();

var username;
var typouser;


var LoadArticulos = async function(){
  let arts = await database.articulos();
  return arts;
}

router.get('/',async function(req, res, next) {
  //Comprobar si hay sesión iniciada y que tipo de sesión
  let arts = await LoadArticulos();
  if(session.user){
    if(session.typouser=="Escritor"){
      username=session.user;
      res.render('index',{username : username, typouser: "Escritor", vista: "home", arts: arts});
    }else if(session.typouser=="admin"){
      username=session.user;
      res.render('index',{username : username, typouser: "admin", vista: "backendHome"});
    }
  }else{
    res.render('index',{username : undefined, typouser: "Lector", vista: "home", arts: arts});
  }
});

//cargar vista contact ----------------------------------------------------------------
router.get("/contact", function(req, res) {
  if(req.session.user){
    username=req.session.user;
    res.render(__dirname + "/../views/index.ejs", {username : username, typouser: "Lector", vista: "contact"});
  }else{
    res.render(__dirname + "/../views/index.ejs", {username : undefined, typouser: "Lector", vista: "contact"});
  }
});

//cargar vista home ----------------------------------------------------------------
router.get("/home", async function(req, res) {
  let arts = await LoadArticulos();
  if(req.session.user){
    username=req.session.user;
    res.render(__dirname + "/../views/index.ejs", {username : username, typouser: "Lector", vista: "home", arts:arts});
  }else{
    res.render(__dirname + "/../views/index.ejs", {username : undefined, typouser: "Lector", vista: "home", arts:arts});
  }
});

/*BACKEND*/
router.get("/homeB", function(req, res){
  username=session.user;
  res.render(__dirname + "/../views/index.ejs", {username : username, typouser: "admin", vista: "backendHome"});
});
router.get("/usuariosB", async function(req, res){
  let users = await database.getUsers();
  username=session.user;
  res.render(__dirname + "/../views/index.ejs", {username : username, typouser: "admin", vista: "backendUsers", users: users});
});
router.get("/artsB", async function(req, res){
  let arts = await LoadArticulos();
  username=session.user;
  res.render(__dirname + "/../views/index.ejs", {username : username, typouser: "admin", vista: "backendArts", arts: arts});
});

//cerrarSesion
router.get("/CerrarSesion", async function(req, res, next) {
  req.session.destroy();
  let arts = await LoadArticulos();
  res.render('index',{username : undefined, typouser: "Lector", vista: "home", arts: arts});
});

module.exports = router;



