const mongoose = require('mongoose');
const DATABASE_CONNECTION = 'mongodb://mongo/miBBDD';
var UserSchema = mongoose.Schema({
    TipoUsuario: String,
    Correo: String,
    Nombre: String,
    Apellidos: String,
    username: String,
    password: String,
    Activado: Boolean,
    titulo: String,
    TipoArticulo: String,
    imagen: String,
    autor: String,
    Descripción: String,
    Contenido: String
});

Usuario = exports.Usuario = mongoose.model('usuarios', UserSchema);
var userModel =mongoose.model('usuarios',UserSchema);
var db = mongoose.connection;
exports.initializeMongo = function(){
    mongoose.connect(DATABASE_CONNECTION, {useNewUrlParser: true});

    console.log('Trying to connect to ' + DATABASE_CONNECTION);

    db = mongoose.connection;
    db.on('error', console.error.bind(console, 'Connection error: We might not be as connected as I thought'));
    db.once('open', function(){
        console.log('Estamos conectados a la base de datos!');
       
    });
}

var add= false;
//Funcion para el login LOGIN----------------------------------------------------
exports.login =async function(user, pws){

      await userModel.findOne({username: user, password: pws}, function(err, c) { // el wait es necesario, ya que si no se ejecuta despues.
          if(c!=null){
              if (c.Activado){
                add=c.TipoUsuario;
              }else{
                add= false;
              }
          }else{
            add= false;
          }
          
       });
       return add;
}

// Registro -----------------------------------------------------------------------
exports.register =function(user){
    addNewUser(user);
}

function addNewUser(user){
    db.collection("usuarios").insert(user);
}

exports.articulos = async function(){
    return await userModel.find({});
}

//BACKEND

exports.getUsers =async function(){
   return await userModel.find({TipoUsuario: {$ne: "admin"}, Nombre: {$ne: undefined}});
}

exports.activarUsuario =async function(correo){
    console.log(correo);
    await userModel.updateOne(
        {Correo: correo},
        {Activado: true}
    );
 }

 exports.eliminarUsuario =async function(correo){
    console.log(correo);
    await userModel.deleteOne(
        {Correo: correo}
    );
 }
 exports.eliminarArticulo =async function(dato){
    console.log(dato);
    await userModel.deleteOne(
        {titulo: dato}
    );
 }
 