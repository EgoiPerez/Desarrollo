const express = require('express');
const database = require('./database');
const indexRouter = require('./routes/index');
const usersRouter = require('./routes/users');
var bodyParser = require('body-parser');
const path = require('path');
var session = require('express-session');
const app = express();
var server = require('http').Server(app);
var io = require('socket.io')(server);

database.initializeMongo();

server.listen(3000, function(){
    console.log("Servidor corriendo en http://192.168.1.36:3000");
});

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
// Session ---------------------------
app.use(session({secret: '123456', resave: true, saveUninitialized: true}));


app.get('/miBBDD', function(req, res){
    database.Usuario.find(function (err, kittens){
        if (err) return res.error(err);
        console.log(kittens);
        res.json(kittens);
    });
});

app.use('/', indexRouter);
app.use('/users', usersRouter);

// LOGIN *******************************************************

var router = express.Router();

router.get("/", function(req, res, next) {
    res.render("login", {
    });
});

//WEBSOCKET
io.on('connection', function(socket){
    socket.on('activacion', async function(data){
        await database.activarUsuario(data);
        //enviar la respuesta de que se ha actualizado el usuario
        socket.emit('activacionCorrecta', data);
    });
    socket.on('ComprobarLogin', async function(data){
        var user = data.user;
        var pw = data.pass;
        //los enviamos a una función del modelo BBDD
        let logged = await database.login(user, pw);
       
        session.user=user;
        session.typouser=logged;

        var sesion={
            tipo: logged,
            user: user
        }

        io.emit('LoginComprobado', sesion);
    });

    socket.on('registrarUser', async function(data){
        var newUser={
            TipoUsuario: data.tipousuario,
            Correo: data.mail,
            Nombre: data.name,
            Apellidos: data.surname,
            username: data.user,
            password: data.pwCheck,
            Activado: false
        }
        //registramos el nuevo usuario
        database.register(newUser);
        //enviamos la notificación
        socket.emit('registroCorrecto');
    });

    //eliminar usuario
    socket.on('eliminarUser', async function(data){
        await database.eliminarUsuario(data);
        //enviar la respuesta de que se ha actualizado el usuario
        socket.emit('eliminacionCorrecta', data);
    });

    socket.on('eliminarArt', async function(data){
        await database.eliminarArticulo(data);
        //enviar la respuesta de que se ha actualizado el usuario
        socket.emit('eliminacionArtCorrecta', data);
    });

});

module.exports = router;
module.exports = app;